﻿namespace Bouwa.Test.GPS
{
    partial class GPSMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStatus = new System.Windows.Forms.Label();
            this.exitMenuItem = new System.Windows.Forms.MenuItem();
            this.stopGpsMenuItem = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.startGpsMenuItem = new System.Windows.Forms.MenuItem();
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.SuspendLayout();
            // 
            // lblStatus
            // 
            this.lblStatus.Location = new System.Drawing.Point(2, 7);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(235, 205);
            this.lblStatus.Text = "label1";
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Text = "Exit";
            this.exitMenuItem.Click += new System.EventHandler(this.exitMenuItem_Click);
            // 
            // stopGpsMenuItem
            // 
            this.stopGpsMenuItem.Enabled = false;
            this.stopGpsMenuItem.Text = "Stop GPS";
            this.stopGpsMenuItem.Click += new System.EventHandler(this.stopGpsMenuItem_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.MenuItems.Add(this.startGpsMenuItem);
            this.menuItem2.MenuItems.Add(this.stopGpsMenuItem);
            this.menuItem2.Text = "GPS";
            // 
            // startGpsMenuItem
            // 
            this.startGpsMenuItem.Text = "Start GPS";
            this.startGpsMenuItem.Click += new System.EventHandler(this.startGpsMenuItem_Click);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.exitMenuItem);
            this.mainMenu1.MenuItems.Add(this.menuItem2);
            // 
            // GPSMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 250);
            this.Controls.Add(this.lblStatus);
            this.Menu = this.mainMenu1;
            this.Name = "GPSMain";
            this.Text = "GPS主窗体";
            this.Load += new System.EventHandler(this.GPSMain_Load);
            this.Closed += new System.EventHandler(this.GPSMain_Closed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.MenuItem exitMenuItem;
        private System.Windows.Forms.MenuItem stopGpsMenuItem;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.MenuItem startGpsMenuItem;
        private System.Windows.Forms.MainMenu mainMenu1;
    }
}