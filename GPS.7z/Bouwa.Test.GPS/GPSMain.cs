﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Bouwa.CentreProducts.GPS;
namespace Bouwa.Test.GPS
{
    public partial class GPSMain : Form
    {
        private EventHandler updateDataHandler;
        GpsDeviceState device = null;
        GpsPosition position = null;
        Gps gps = new Gps();


        public GPSMain()
        {
            InitializeComponent();
        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            if (gps.Opened)
            {
                gps.Close();
            }

            Close();
        }

        private void GPSMain_Load(object sender, EventArgs e)
        {
            updateDataHandler = new EventHandler(UpdateData);

            lblStatus.Text = "";

            //控件屏幕自适应
            //lblStatus.Width = Screen.PrimaryScreen.WorkingArea.Width;
            //lblStatus.Height = Screen.PrimaryScreen.WorkingArea.Height;
            
            ///注册变更事件
            gps.DeviceStateChanged += new DeviceStateChangedEventHandler(gps_DeviceStateChanged);
            gps.LocationChanged += new LocationChangedEventHandler(gps_LocationChanged);
        }

        protected void gps_LocationChanged(object sender, LocationChangedEventArgs args)
        {
            position = args.Position;
            ///线程中,异步调用变更事件
            Invoke(updateDataHandler);

        }

        void gps_DeviceStateChanged(object sender, DeviceStateChangedEventArgs args)
        {
            device = args.DeviceState;

            ///线程中,异步调用变更事件
            Invoke(updateDataHandler);
        }

        /// <summary>
        /// Longitude经度Latitude纬度发送变化时，触发事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        void UpdateData(object sender, System.EventArgs args)
        {
            if (gps.Opened)
            {
                string str = "";
                if (device != null)
                {
                    str = device.FriendlyName + "设备服务状态：" + device.ServiceState + ",设备状态：" + device.DeviceState + "\n";
                }

                if (position != null)
                {

                    if (position.LatitudeValid)
                    {
                        str += "纬度 (DD):\n   " + position.Latitude + "\n";
                        str += "纬度 (D,M,S):\n   " + position.LatitudeInDegreesMinutesSeconds + "\n";
                    }

                    if (position.LongitudeValid)
                    {
                        str += "经度 (DD):\n   " + position.Longitude + "\n";
                        str += "经度 (D,M,S):\n   " + position.LongitudeInDegreesMinutesSeconds + "\n";
                    }

                    if (position.SatellitesInSolutionValid &&
                        position.SatellitesInViewValid &&
                        position.SatelliteCountValid)
                    {
                        //str += "Satellite Count:\n   " + position.GetSatellitesInSolution().Length + "/" +
                        str += "可用卫星数量:\n   " + position.GetSatellitesInSolution().Length + "/" +
                            position.GetSatellitesInView().Length + " (" +
                            position.SatelliteCount + ")\n";
                    }

                    if (position.TimeValid)
                    {
                        str += "时间:\n   " + position.Time.ToString() + "\n";
                    }
                }

                lblStatus.Text = str;

            }
        }

     

        private void stopGpsMenuItem_Click(object sender, EventArgs e)
        {
            if (gps.Opened)
            {
                gps.Close();
            }

            startGpsMenuItem.Enabled = true;
            stopGpsMenuItem.Enabled = false;
        }

        private void startGpsMenuItem_Click(object sender, EventArgs e)
        {
            if (!gps.Opened)
            {
                gps.Open();
            }

            startGpsMenuItem.Enabled = false;
            stopGpsMenuItem.Enabled = true;
        }

        private void GPSMain_Closed(object sender, EventArgs e)
        {
            if (gps.Opened)
            {
                gps.Close();
            }

            startGpsMenuItem.Enabled = true;
            stopGpsMenuItem.Enabled = false;
        }

    }
}