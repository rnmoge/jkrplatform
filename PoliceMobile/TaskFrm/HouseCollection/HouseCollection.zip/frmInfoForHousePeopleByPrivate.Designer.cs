﻿namespace PoliceMobile.TaskFrm.HouseCollection
{
    partial class frmInfoForHousePeopleByPrivate
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInfoForHousePeopleByPrivate));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.mainMenu2 = new System.Windows.Forms.MainMenu();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnReSet = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBirth = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtLink = new System.Windows.Forms.TextBox();
            this.txtInfo = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSex = new System.Windows.Forms.TextBox();
            this.txtNation = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCardId = new System.Windows.Forms.TextBox();
            this.btnScanIDCard = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbPrivate = new System.Windows.Forms.PictureBox();
            this.pbPublic = new System.Windows.Forms.PictureBox();
            this.ucControlManager1 = new PoliceMobile.LIB.ucControlManager();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBox1.Location = new System.Drawing.Point(12, 121);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(457, 38);
            this.textBox1.TabIndex = 20;
            this.textBox1.Tag = "Info/Address";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(20, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 28);
            this.label6.Text = "选择详细地址";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(512, 30);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(326, 70);
            // 
            // btnReSet
            // 
            this.btnReSet.Image = ((System.Drawing.Image)(resources.GetObject("btnReSet.Image")));
            this.btnReSet.Location = new System.Drawing.Point(278, 5);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(187, 44);
            this.btnReSet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(148)))), ((int)(((byte)(156)))));
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Controls.Add(this.btnSave);
            this.panel7.Controls.Add(this.btnReSet);
            this.panel7.Location = new System.Drawing.Point(0, 625);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(481, 55);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(17, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(187, 44);
            this.btnSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtName.Location = new System.Drawing.Point(117, 303);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(109, 29);
            this.txtName.TabIndex = 21;
            this.txtName.Tag = "House_Private/Master/Name";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label7.Location = new System.Drawing.Point(20, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 18);
            this.label7.Text = "房主姓名";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label8.Location = new System.Drawing.Point(20, 345);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 17);
            this.label8.Text = "出生日期";
            // 
            // txtBirth
            // 
            this.txtBirth.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtBirth.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtBirth.Location = new System.Drawing.Point(117, 339);
            this.txtBirth.Multiline = true;
            this.txtBirth.Name = "txtBirth";
            this.txtBirth.ReadOnly = true;
            this.txtBirth.Size = new System.Drawing.Size(109, 31);
            this.txtBirth.TabIndex = 21;
            this.txtBirth.Tag = "House_Private/Master/Birth";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label9.Location = new System.Drawing.Point(20, 418);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 20);
            this.label9.Text = "联系方式";
            // 
            // txtLink
            // 
            this.txtLink.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtLink.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtLink.Location = new System.Drawing.Point(115, 415);
            this.txtLink.Multiline = true;
            this.txtLink.Name = "txtLink";
            this.txtLink.Size = new System.Drawing.Size(341, 27);
            this.txtLink.TabIndex = 21;
            this.txtLink.Tag = "House_Private/Master/LinkMethod";
            // 
            // txtInfo
            // 
            this.txtInfo.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.txtInfo.Location = new System.Drawing.Point(20, 455);
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.Size = new System.Drawing.Size(118, 24);
            this.txtInfo.Text = "备       注";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox5.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.textBox5.Location = new System.Drawing.Point(115, 452);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(341, 94);
            this.textBox5.TabIndex = 21;
            this.textBox5.Tag = "House_Private/Master/Comment";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 528);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(480, 60);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 265);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(481, 5);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label16.Location = new System.Drawing.Point(245, 306);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 18);
            this.label16.Text = "性别";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label17.Location = new System.Drawing.Point(245, 345);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(118, 17);
            this.label17.Text = "名族";
            // 
            // txtSex
            // 
            this.txtSex.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSex.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtSex.Location = new System.Drawing.Point(303, 303);
            this.txtSex.Multiline = true;
            this.txtSex.Name = "txtSex";
            this.txtSex.ReadOnly = true;
            this.txtSex.Size = new System.Drawing.Size(109, 29);
            this.txtSex.TabIndex = 21;
            this.txtSex.Tag = "House_Private/Master/Sex";
            // 
            // txtNation
            // 
            this.txtNation.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtNation.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtNation.Location = new System.Drawing.Point(303, 338);
            this.txtNation.Multiline = true;
            this.txtNation.Name = "txtNation";
            this.txtNation.ReadOnly = true;
            this.txtNation.Size = new System.Drawing.Size(109, 31);
            this.txtNation.TabIndex = 21;
            this.txtNation.Tag = "House_Private/Master/Nation";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label18.Location = new System.Drawing.Point(20, 383);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 20);
            this.label18.Text = "身份证号";
            // 
            // txtCardId
            // 
            this.txtCardId.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCardId.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtCardId.Location = new System.Drawing.Point(115, 378);
            this.txtCardId.Multiline = true;
            this.txtCardId.Name = "txtCardId";
            this.txtCardId.ReadOnly = true;
            this.txtCardId.Size = new System.Drawing.Size(341, 27);
            this.txtCardId.TabIndex = 21;
            this.txtCardId.Tag = "House_Private/Master/ID";
            // 
            // btnScanIDCard
            // 
            this.btnScanIDCard.Image = ((System.Drawing.Image)(resources.GetObject("btnScanIDCard.Image")));
            this.btnScanIDCard.Location = new System.Drawing.Point(152, 558);
            this.btnScanIDCard.Name = "btnScanIDCard";
            this.btnScanIDCard.Size = new System.Drawing.Size(187, 54);
            this.btnScanIDCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnScanIDCard.Click += new System.EventHandler(this.btnScanIDCard_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(331, 194);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(110, 40);
            this.checkBox1.TabIndex = 62;
            this.checkBox1.Text = "出租";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(163, 143);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // pbPrivate
            // 
            this.pbPrivate.Image = ((System.Drawing.Image)(resources.GetObject("pbPrivate.Image")));
            this.pbPrivate.Location = new System.Drawing.Point(248, 266);
            this.pbPrivate.Name = "pbPrivate";
            this.pbPrivate.Size = new System.Drawing.Size(128, 57);
            this.pbPrivate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            // 
            // pbPublic
            // 
            this.pbPublic.Image = ((System.Drawing.Image)(resources.GetObject("pbPublic.Image")));
            this.pbPublic.Location = new System.Drawing.Point(248, 266);
            this.pbPublic.Name = "pbPublic";
            this.pbPublic.Size = new System.Drawing.Size(128, 57);
            this.pbPublic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            // 
            // ucControlManager1
            // 
            this.ucControlManager1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucControlManager1.Location = new System.Drawing.Point(0, 0);
            this.ucControlManager1.Name = "ucControlManager1";
            this.ucControlManager1.Size = new System.Drawing.Size(480, 67);
            this.ucControlManager1.TabIndex = 36;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(278, 365);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(187, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.Click += new System.EventHandler(this.btnScanIDCard_Click);
            // 
            // frmInfoForHousePeopleByPrivate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(480, 588);
            this.Controls.Add(this.pbPrivate);
            this.Controls.Add(this.pbPublic);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.ucControlManager1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.btnScanIDCard);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.txtCardId);
            this.Controls.Add(this.txtLink);
            this.Controls.Add(this.txtNation);
            this.Controls.Add(this.txtBirth);
            this.Controls.Add(this.txtSex);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtInfo);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel7);
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "frmInfoForHousePeopleByPrivate";
            this.Text = "frmInfoForHouseByPrivate";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MainMenu mainMenu2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox btnReSet;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBirth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtLink;
        private System.Windows.Forms.Label txtInfo;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtSex;
        private System.Windows.Forms.TextBox txtNation;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCardId;
        private System.Windows.Forms.PictureBox btnScanIDCard;
        private PoliceMobile.LIB.ucControlManager ucControlManager1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbPrivate;
        private System.Windows.Forms.PictureBox pbPublic;
        private System.Windows.Forms.PictureBox pictureBox5;


    }
}