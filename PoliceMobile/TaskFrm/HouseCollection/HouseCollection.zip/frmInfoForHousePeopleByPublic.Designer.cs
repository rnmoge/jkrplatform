﻿namespace PoliceMobile.TaskFrm.HouseCollection
{
    partial class frmInfoForHousePeopleByPublic
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInfoForHousePeopleByPublic));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.mainMenu2 = new System.Windows.Forms.MainMenu();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnReSet = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMasterAddress = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtLinkMethod = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLinkName = new System.Windows.Forms.TextBox();
            this.cbGender = new System.Windows.Forms.CheckBox();
            this.pbPublic = new System.Windows.Forms.PictureBox();
            this.pbPrivate = new System.Windows.Forms.PictureBox();
            this.ucControlManager1 = new PoliceMobile.LIB.ucControlManager();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtAddress.Location = new System.Drawing.Point(12, 121);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(457, 38);
            this.txtAddress.TabIndex = 20;
            this.txtAddress.Tag = "Info/Address";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(20, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 28);
            this.label6.Text = "选择详细地址";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(512, 30);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(326, 70);
            // 
            // btnReSet
            // 
            this.btnReSet.Image = ((System.Drawing.Image)(resources.GetObject("btnReSet.Image")));
            this.btnReSet.Location = new System.Drawing.Point(278, 5);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(187, 44);
            this.btnReSet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(148)))), ((int)(((byte)(156)))));
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Controls.Add(this.btnSave);
            this.panel7.Controls.Add(this.btnReSet);
            this.panel7.Location = new System.Drawing.Point(0, 625);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(481, 55);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(17, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(187, 44);
            this.btnSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtName.Location = new System.Drawing.Point(139, 303);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(318, 28);
            this.txtName.TabIndex = 21;
            this.txtName.Tag = "House_Public/Master/Name";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label7.Location = new System.Drawing.Point(20, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 18);
            this.label7.Text = "房主单位名称";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label8.Location = new System.Drawing.Point(20, 345);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 17);
            this.label8.Text = "房主单位地址";
            // 
            // txtMasterAddress
            // 
            this.txtMasterAddress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtMasterAddress.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtMasterAddress.Location = new System.Drawing.Point(139, 344);
            this.txtMasterAddress.Multiline = true;
            this.txtMasterAddress.Name = "txtMasterAddress";
            this.txtMasterAddress.Size = new System.Drawing.Size(318, 55);
            this.txtMasterAddress.TabIndex = 21;
            this.txtMasterAddress.Tag = "House_Public/Master/Address";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label9.Location = new System.Drawing.Point(20, 456);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 20);
            this.label9.Text = "联  系  方  式";
            // 
            // txtLinkMethod
            // 
            this.txtLinkMethod.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtLinkMethod.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtLinkMethod.Location = new System.Drawing.Point(139, 457);
            this.txtLinkMethod.Multiline = true;
            this.txtLinkMethod.Name = "txtLinkMethod";
            this.txtLinkMethod.Size = new System.Drawing.Size(318, 27);
            this.txtLinkMethod.TabIndex = 21;
            this.txtLinkMethod.Tag = "House_Public/Master/LinkMethod";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label10.Location = new System.Drawing.Point(20, 499);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 24);
            this.label10.Text = "备             注";
            // 
            // txtComment
            // 
            this.txtComment.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtComment.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtComment.Location = new System.Drawing.Point(139, 500);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(318, 105);
            this.txtComment.TabIndex = 21;
            this.txtComment.Tag = "House_Public/Master/Comment";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 528);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(480, 60);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 265);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(481, 5);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label1.Location = new System.Drawing.Point(20, 417);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 20);
            this.label1.Text = "联系人姓名";
            // 
            // txtLinkName
            // 
            this.txtLinkName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtLinkName.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtLinkName.Location = new System.Drawing.Point(139, 414);
            this.txtLinkName.Multiline = true;
            this.txtLinkName.Name = "txtLinkName";
            this.txtLinkName.Size = new System.Drawing.Size(318, 27);
            this.txtLinkName.TabIndex = 21;
            this.txtLinkName.Tag = "House_Public/Master/LinkName";
            // 
            // cbGender
            // 
            this.cbGender.Location = new System.Drawing.Point(331, 194);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(110, 40);
            this.cbGender.TabIndex = 65;
            this.cbGender.Text = "出租";
            // 
            // pbPublic
            // 
            this.pbPublic.Image = ((System.Drawing.Image)(resources.GetObject("pbPublic.Image")));
            this.pbPublic.Location = new System.Drawing.Point(5, 187);
            this.pbPublic.Name = "pbPublic";
            this.pbPublic.Size = new System.Drawing.Size(122, 56);
            this.pbPublic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            // 
            // pbPrivate
            // 
            this.pbPrivate.Image = ((System.Drawing.Image)(resources.GetObject("pbPrivate.Image")));
            this.pbPrivate.Location = new System.Drawing.Point(146, 186);
            this.pbPrivate.Name = "pbPrivate";
            this.pbPrivate.Size = new System.Drawing.Size(122, 56);
            this.pbPrivate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbPrivate.Click += new System.EventHandler(this.pbPrivate_Click);
            // 
            // ucControlManager1
            // 
            this.ucControlManager1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucControlManager1.Location = new System.Drawing.Point(0, 0);
            this.ucControlManager1.Name = "ucControlManager1";
            this.ucControlManager1.Size = new System.Drawing.Size(480, 67);
            this.ucControlManager1.TabIndex = 33;
            // 
            // frmInfoForHousePeopleByPublic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(480, 588);
            this.Controls.Add(this.pbPrivate);
            this.Controls.Add(this.pbPublic);
            this.Controls.Add(this.cbGender);
            this.Controls.Add(this.ucControlManager1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.txtComment);
            this.Controls.Add(this.txtLinkName);
            this.Controls.Add(this.txtLinkMethod);
            this.Controls.Add(this.txtMasterAddress);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel7);
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "frmInfoForHousePeopleByPublic";
            this.Text = "frmInfoForHouseByPublic";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.MainMenu mainMenu2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox btnReSet;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMasterAddress;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtLinkMethod;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private PoliceMobile.LIB.ucControlManager ucControlManager1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLinkName;
        private System.Windows.Forms.CheckBox cbGender;
        private System.Windows.Forms.PictureBox pbPublic;
        private System.Windows.Forms.PictureBox pbPrivate;


    }
}