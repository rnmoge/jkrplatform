﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PoliceMobile.LIB;
using PoliceMobile.CLS;

namespace PoliceMobile.TaskFrm.HouseCollection
{
    public partial class frmInfoForStreet : Form
    {
        public frmInfoForStreet()
        {
            InitializeComponent();
            init();
            ucControlManager1.pStreet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(224)))), ((int)(((byte)(255)))));
        }

        private void init()
        {
            //FrmManager.fifs = this;
            ToolsHelper.BindDataForComboBox("HouseType", cbHouseType, "");
            ToolsHelper.BindDataForComboBox("HouseTypeBase", cbHouseBase, "");

            if (ToolsHelper.sHouseGuid != "")
            {
                Boolean isOK = ToolsHelper.AutoLoadConfigForHouse(this, ToolsHelper.sHouseGuid);
                if (isOK)
                {
                    ToolsHelper.iFlag = 0;
                }
                else
                {
                    ToolsHelper.iFlag = 1;
                }
            }
        }

        private void cbHouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbHouseBase.Text == "非居住房")
            {
                cbHouseType.Enabled = true;
            }
            else
            {
                cbHouseType.Enabled = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sGuid = ToolsHelper.sHouseGuid;
            if (sGuid == "")
            {
                sGuid = Guid.NewGuid().ToString();
            }
            ToolsHelper.AutoSaveConfigForHouse(this, sGuid);
            ToolsHelper.sHouseGuid = sGuid;

            ToolsHelper.iFlag = 1;

            FrmManager.showWindowFor_frmInfoForHousePeopleByPrivate();
        }

        private void btnDesktop_Click(object sender, EventArgs e)
        {
            FrmManager.showWindowFor_FrmDesktop();
        }
    }
}