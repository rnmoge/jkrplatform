﻿namespace PoliceMobile.TaskFrm.HouseCollection
{
    partial class frmInfoForStreet
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInfoForStreet));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.mainMenu2 = new System.Windows.Forms.MainMenu();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnReSet = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtInfo = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnGPS = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbHouseBase = new System.Windows.Forms.ComboBox();
            this.cbHouseType = new System.Windows.Forms.ComboBox();
            this.txtGps = new System.Windows.Forms.TextBox();
            this.btnDesktop = new System.Windows.Forms.Button();
            this.ucControlManager1 = new PoliceMobile.LIB.ucControlManager();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtStreet
            // 
            this.txtStreet.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtStreet.Location = new System.Drawing.Point(12, 208);
            this.txtStreet.Multiline = true;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(457, 38);
            this.txtStreet.TabIndex = 20;
            this.txtStreet.Tag = "Info/Street";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(20, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 28);
            this.label6.Text = "选择街道地址";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(512, 30);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(326, 70);
            // 
            // btnReSet
            // 
            this.btnReSet.Image = ((System.Drawing.Image)(resources.GetObject("btnReSet.Image")));
            this.btnReSet.Location = new System.Drawing.Point(278, 5);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(187, 44);
            this.btnReSet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(148)))), ((int)(((byte)(156)))));
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Controls.Add(this.btnSave);
            this.panel7.Controls.Add(this.btnReSet);
            this.panel7.Location = new System.Drawing.Point(0, 625);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(481, 55);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(17, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(187, 44);
            this.btnSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.label10.Location = new System.Drawing.Point(25, 367);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 24);
            this.label10.Text = "备     注";
            // 
            // txtInfo
            // 
            this.txtInfo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtInfo.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.txtInfo.Location = new System.Drawing.Point(25, 397);
            this.txtInfo.Multiline = true;
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.Size = new System.Drawing.Size(429, 113);
            this.txtInfo.TabIndex = 21;
            this.txtInfo.Tag = "Info/Comment";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 528);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(480, 60);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 345);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(481, 5);
            // 
            // btnGPS
            // 
            this.btnGPS.Image = ((System.Drawing.Image)(resources.GetObject("btnGPS.Image")));
            this.btnGPS.Location = new System.Drawing.Point(148, 278);
            this.btnGPS.Name = "btnGPS";
            this.btnGPS.Size = new System.Drawing.Size(161, 46);
            this.btnGPS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(-4, 257);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(481, 5);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(20, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 28);
            this.label1.Text = "房屋类型选择";
            // 
            // cbHouseBase
            // 
            this.cbHouseBase.Items.Add("居住房");
            this.cbHouseBase.Items.Add("非居住房");
            this.cbHouseBase.Location = new System.Drawing.Point(12, 122);
            this.cbHouseBase.Name = "cbHouseBase";
            this.cbHouseBase.Size = new System.Drawing.Size(157, 41);
            this.cbHouseBase.TabIndex = 34;
            this.cbHouseBase.Tag = "Info/HouseBase";
            this.cbHouseBase.SelectedIndexChanged += new System.EventHandler(this.cbHouse_SelectedIndexChanged);
            // 
            // cbHouseType
            // 
            this.cbHouseType.Enabled = false;
            this.cbHouseType.Location = new System.Drawing.Point(175, 122);
            this.cbHouseType.Name = "cbHouseType";
            this.cbHouseType.Size = new System.Drawing.Size(294, 41);
            this.cbHouseType.TabIndex = 34;
            this.cbHouseType.Tag = "Info/HouseType";
            // 
            // txtGps
            // 
            this.txtGps.Location = new System.Drawing.Point(342, 282);
            this.txtGps.Name = "txtGps";
            this.txtGps.Size = new System.Drawing.Size(112, 41);
            this.txtGps.TabIndex = 35;
            this.txtGps.Tag = "Info/GPS";
            // 
            // btnDesktop
            // 
            this.btnDesktop.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.btnDesktop.Location = new System.Drawing.Point(362, 540);
            this.btnDesktop.Name = "btnDesktop";
            this.btnDesktop.Size = new System.Drawing.Size(92, 36);
            this.btnDesktop.TabIndex = 43;
            this.btnDesktop.Text = "返回桌面";
            this.btnDesktop.Click += new System.EventHandler(this.btnDesktop_Click);
            // 
            // ucControlManager1
            // 
            this.ucControlManager1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucControlManager1.Location = new System.Drawing.Point(0, 0);
            this.ucControlManager1.Name = "ucControlManager1";
            this.ucControlManager1.Size = new System.Drawing.Size(480, 67);
            this.ucControlManager1.TabIndex = 25;
            // 
            // frmInfoForStreet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(480, 588);
            this.Controls.Add(this.btnDesktop);
            this.Controls.Add(this.btnGPS);
            this.Controls.Add(this.txtGps);
            this.Controls.Add(this.cbHouseType);
            this.Controls.Add(this.cbHouseBase);
            this.Controls.Add(this.ucControlManager1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.txtInfo);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel7);
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "frmInfoForStreet";
            this.Text = "frmInfoForStreet";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.MainMenu mainMenu2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox btnReSet;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtInfo;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox btnGPS;
        private System.Windows.Forms.PictureBox pictureBox6;
        private PoliceMobile.LIB.ucControlManager ucControlManager1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbHouseBase;
        private System.Windows.Forms.ComboBox cbHouseType;
        private System.Windows.Forms.TextBox txtGps;
        private System.Windows.Forms.Button btnDesktop;


    }
}