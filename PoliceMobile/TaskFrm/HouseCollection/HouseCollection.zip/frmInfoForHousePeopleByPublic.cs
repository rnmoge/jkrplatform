﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PoliceMobile.CLS;
using PoliceMobile.LIB;

namespace PoliceMobile.TaskFrm.HouseCollection
{
    public partial class frmInfoForHousePeopleByPublic : Form
    {
        public frmInfoForHousePeopleByPublic()
        {
            InitializeComponent();
            init();
        }

        private void init()
        {
            ToolsHelper.AutoLoadConfigForHouse(this, ToolsHelper.sHouseGuid);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ToolsHelper.AutoSaveConfigForHouse(this, ToolsHelper.sHouseGuid);
        }

        private void pbPrivate_Click(object sender, EventArgs e)
        {
            FrmManager.showWindowFor_frmInfoForHousePeopleByPrivate();
        }
    }
}