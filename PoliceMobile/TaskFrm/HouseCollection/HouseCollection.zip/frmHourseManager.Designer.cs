namespace PoliceMobile.TaskFrm.HouseCollection
{
    partial class frmHouseManager
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHouseManager));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.mainMenu2 = new System.Windows.Forms.MainMenu();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnReSet = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bgPanel = new System.Windows.Forms.Panel();
            this.pBack10 = new System.Windows.Forms.Panel();
            this.lblCreate10 = new System.Windows.Forms.Label();
            this.lblSteet10 = new System.Windows.Forms.Label();
            this.lblId10 = new System.Windows.Forms.Label();
            this.pbUpload10 = new System.Windows.Forms.PictureBox();
            this.pbIn10 = new System.Windows.Forms.PictureBox();
            this.pBack9 = new System.Windows.Forms.Panel();
            this.lblCreate9 = new System.Windows.Forms.Label();
            this.lblSteet9 = new System.Windows.Forms.Label();
            this.lblId9 = new System.Windows.Forms.Label();
            this.pbUpload19 = new System.Windows.Forms.PictureBox();
            this.pbIn9 = new System.Windows.Forms.PictureBox();
            this.pBack8 = new System.Windows.Forms.Panel();
            this.lblCreate8 = new System.Windows.Forms.Label();
            this.lblSteet8 = new System.Windows.Forms.Label();
            this.lblId8 = new System.Windows.Forms.Label();
            this.pbUpload8 = new System.Windows.Forms.PictureBox();
            this.pbIn8 = new System.Windows.Forms.PictureBox();
            this.pBack7 = new System.Windows.Forms.Panel();
            this.lblCreate7 = new System.Windows.Forms.Label();
            this.lblSteet7 = new System.Windows.Forms.Label();
            this.lblId7 = new System.Windows.Forms.Label();
            this.pbUpload7 = new System.Windows.Forms.PictureBox();
            this.pbIn7 = new System.Windows.Forms.PictureBox();
            this.pBack6 = new System.Windows.Forms.Panel();
            this.lblCreate6 = new System.Windows.Forms.Label();
            this.lblSteet6 = new System.Windows.Forms.Label();
            this.lblId6 = new System.Windows.Forms.Label();
            this.pbUpload6 = new System.Windows.Forms.PictureBox();
            this.pbIn6 = new System.Windows.Forms.PictureBox();
            this.pBack5 = new System.Windows.Forms.Panel();
            this.lblCreate5 = new System.Windows.Forms.Label();
            this.lblSteet5 = new System.Windows.Forms.Label();
            this.lblId5 = new System.Windows.Forms.Label();
            this.pbUpload5 = new System.Windows.Forms.PictureBox();
            this.pbIn5 = new System.Windows.Forms.PictureBox();
            this.pBack4 = new System.Windows.Forms.Panel();
            this.lblCreate4 = new System.Windows.Forms.Label();
            this.lblSteet4 = new System.Windows.Forms.Label();
            this.lblId4 = new System.Windows.Forms.Label();
            this.pbUpload4 = new System.Windows.Forms.PictureBox();
            this.pbIn4 = new System.Windows.Forms.PictureBox();
            this.pBack3 = new System.Windows.Forms.Panel();
            this.lblCreate3 = new System.Windows.Forms.Label();
            this.lblSteet3 = new System.Windows.Forms.Label();
            this.lblId3 = new System.Windows.Forms.Label();
            this.pbUpload3 = new System.Windows.Forms.PictureBox();
            this.pbIn3 = new System.Windows.Forms.PictureBox();
            this.pBack2 = new System.Windows.Forms.Panel();
            this.lblCreate2 = new System.Windows.Forms.Label();
            this.lblSteet2 = new System.Windows.Forms.Label();
            this.lblId2 = new System.Windows.Forms.Label();
            this.pbUpload2 = new System.Windows.Forms.PictureBox();
            this.pbIn2 = new System.Windows.Forms.PictureBox();
            this.pBack1 = new System.Windows.Forms.Panel();
            this.lblCreate1 = new System.Windows.Forms.Label();
            this.lblSteet1 = new System.Windows.Forms.Label();
            this.lblId1 = new System.Windows.Forms.Label();
            this.pbUpload1 = new System.Windows.Forms.PictureBox();
            this.pbIn1 = new System.Windows.Forms.PictureBox();
            this.pBUploadAll = new System.Windows.Forms.PictureBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.ucControlManager1 = new PoliceMobile.LIB.ucControlManager();
            this.panel7.SuspendLayout();
            this.bgPanel.SuspendLayout();
            this.pBack10.SuspendLayout();
            this.pBack9.SuspendLayout();
            this.pBack8.SuspendLayout();
            this.pBack7.SuspendLayout();
            this.pBack6.SuspendLayout();
            this.pBack5.SuspendLayout();
            this.pBack4.SuspendLayout();
            this.pBack3.SuspendLayout();
            this.pBack2.SuspendLayout();
            this.pBack1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(512, 30);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(326, 70);
            // 
            // btnReSet
            // 
            this.btnReSet.Image = ((System.Drawing.Image)(resources.GetObject("btnReSet.Image")));
            this.btnReSet.Location = new System.Drawing.Point(278, 5);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(187, 44);
            this.btnReSet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnReSet.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(148)))), ((int)(((byte)(156)))));
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Controls.Add(this.btnSave);
            this.panel7.Controls.Add(this.btnReSet);
            this.panel7.Location = new System.Drawing.Point(0, 625);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(481, 55);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(17, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(187, 44);
            this.btnSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSave.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 528);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(480, 60);
            // 
            // bgPanel
            // 
            this.bgPanel.Controls.Add(this.pBack10);
            this.bgPanel.Controls.Add(this.pBack9);
            this.bgPanel.Controls.Add(this.pBack8);
            this.bgPanel.Controls.Add(this.pBack7);
            this.bgPanel.Controls.Add(this.pBack6);
            this.bgPanel.Controls.Add(this.pBack5);
            this.bgPanel.Controls.Add(this.pBack4);
            this.bgPanel.Controls.Add(this.pBack3);
            this.bgPanel.Controls.Add(this.pBack2);
            this.bgPanel.Controls.Add(this.pBack1);
            this.bgPanel.Location = new System.Drawing.Point(17, 84);
            this.bgPanel.Name = "bgPanel";
            this.bgPanel.Size = new System.Drawing.Size(451, 465);
            // 
            // pBack10
            // 
            this.pBack10.Controls.Add(this.lblCreate10);
            this.pBack10.Controls.Add(this.lblSteet10);
            this.pBack10.Controls.Add(this.lblId10);
            this.pBack10.Controls.Add(this.pbUpload10);
            this.pBack10.Controls.Add(this.pbIn10);
            this.pBack10.Location = new System.Drawing.Point(4, 417);
            this.pBack10.Name = "pBack10";
            this.pBack10.Size = new System.Drawing.Size(444, 40);
            this.pBack10.Visible = false;
            this.pBack10.GotFocus += new System.EventHandler(this.p10_GotFocus);
            // 
            // lblCreate10
            // 
            this.lblCreate10.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate10.Location = new System.Drawing.Point(188, 10);
            this.lblCreate10.Name = "lblCreate10";
            this.lblCreate10.Size = new System.Drawing.Size(138, 20);
            this.lblCreate10.Text = "2011-12-20 19:45";
            // 
            // lblSteet10
            // 
            this.lblSteet10.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet10.Location = new System.Drawing.Point(27, 11);
            this.lblSteet10.Name = "lblSteet10";
            this.lblSteet10.Size = new System.Drawing.Size(157, 19);
            this.lblSteet10.Text = "街道地址";
            // 
            // lblId10
            // 
            this.lblId10.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId10.Location = new System.Drawing.Point(4, 12);
            this.lblId10.Name = "lblId10";
            this.lblId10.Size = new System.Drawing.Size(39, 30);
            this.lblId10.Text = "10";
            // 
            // pbUpload10
            // 
            this.pbUpload10.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload10.Image")));
            this.pbUpload10.Location = new System.Drawing.Point(384, 3);
            this.pbUpload10.Name = "pbUpload10";
            this.pbUpload10.Size = new System.Drawing.Size(55, 31);
            this.pbUpload10.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn10
            // 
            this.pbIn10.Image = ((System.Drawing.Image)(resources.GetObject("pbIn10.Image")));
            this.pbIn10.Location = new System.Drawing.Point(332, 3);
            this.pbIn10.Name = "pbIn10";
            this.pbIn10.Size = new System.Drawing.Size(52, 31);
            this.pbIn10.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack9
            // 
            this.pBack9.Controls.Add(this.lblCreate9);
            this.pBack9.Controls.Add(this.lblSteet9);
            this.pBack9.Controls.Add(this.lblId9);
            this.pBack9.Controls.Add(this.pbUpload19);
            this.pBack9.Controls.Add(this.pbIn9);
            this.pBack9.Location = new System.Drawing.Point(4, 371);
            this.pBack9.Name = "pBack9";
            this.pBack9.Size = new System.Drawing.Size(444, 40);
            this.pBack9.Visible = false;
            // 
            // lblCreate9
            // 
            this.lblCreate9.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate9.Location = new System.Drawing.Point(188, 10);
            this.lblCreate9.Name = "lblCreate9";
            this.lblCreate9.Size = new System.Drawing.Size(138, 20);
            this.lblCreate9.Text = "2011-12-20 19:45";
            // 
            // lblSteet9
            // 
            this.lblSteet9.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet9.Location = new System.Drawing.Point(27, 11);
            this.lblSteet9.Name = "lblSteet9";
            this.lblSteet9.Size = new System.Drawing.Size(157, 19);
            this.lblSteet9.Text = "街道地址";
            // 
            // lblId9
            // 
            this.lblId9.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId9.Location = new System.Drawing.Point(10, 12);
            this.lblId9.Name = "lblId9";
            this.lblId9.Size = new System.Drawing.Size(39, 30);
            this.lblId9.Text = "9";
            // 
            // pbUpload19
            // 
            this.pbUpload19.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload19.Image")));
            this.pbUpload19.Location = new System.Drawing.Point(384, 3);
            this.pbUpload19.Name = "pbUpload19";
            this.pbUpload19.Size = new System.Drawing.Size(55, 31);
            this.pbUpload19.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn9
            // 
            this.pbIn9.Image = ((System.Drawing.Image)(resources.GetObject("pbIn9.Image")));
            this.pbIn9.Location = new System.Drawing.Point(332, 3);
            this.pbIn9.Name = "pbIn9";
            this.pbIn9.Size = new System.Drawing.Size(52, 31);
            this.pbIn9.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack8
            // 
            this.pBack8.Controls.Add(this.lblCreate8);
            this.pBack8.Controls.Add(this.lblSteet8);
            this.pBack8.Controls.Add(this.lblId8);
            this.pBack8.Controls.Add(this.pbUpload8);
            this.pBack8.Controls.Add(this.pbIn8);
            this.pBack8.Location = new System.Drawing.Point(4, 325);
            this.pBack8.Name = "pBack8";
            this.pBack8.Size = new System.Drawing.Size(444, 40);
            this.pBack8.Visible = false;
            // 
            // lblCreate8
            // 
            this.lblCreate8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate8.Location = new System.Drawing.Point(188, 10);
            this.lblCreate8.Name = "lblCreate8";
            this.lblCreate8.Size = new System.Drawing.Size(138, 20);
            this.lblCreate8.Text = "2011-12-20 19:45";
            // 
            // lblSteet8
            // 
            this.lblSteet8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet8.Location = new System.Drawing.Point(27, 11);
            this.lblSteet8.Name = "lblSteet8";
            this.lblSteet8.Size = new System.Drawing.Size(157, 19);
            this.lblSteet8.Text = "街道地址";
            // 
            // lblId8
            // 
            this.lblId8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId8.Location = new System.Drawing.Point(10, 12);
            this.lblId8.Name = "lblId8";
            this.lblId8.Size = new System.Drawing.Size(39, 30);
            this.lblId8.Text = "8";
            // 
            // pbUpload8
            // 
            this.pbUpload8.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload8.Image")));
            this.pbUpload8.Location = new System.Drawing.Point(384, 3);
            this.pbUpload8.Name = "pbUpload8";
            this.pbUpload8.Size = new System.Drawing.Size(55, 31);
            this.pbUpload8.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn8
            // 
            this.pbIn8.Image = ((System.Drawing.Image)(resources.GetObject("pbIn8.Image")));
            this.pbIn8.Location = new System.Drawing.Point(332, 3);
            this.pbIn8.Name = "pbIn8";
            this.pbIn8.Size = new System.Drawing.Size(52, 31);
            this.pbIn8.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack7
            // 
            this.pBack7.Controls.Add(this.lblCreate7);
            this.pBack7.Controls.Add(this.lblSteet7);
            this.pBack7.Controls.Add(this.lblId7);
            this.pBack7.Controls.Add(this.pbUpload7);
            this.pBack7.Controls.Add(this.pbIn7);
            this.pBack7.Location = new System.Drawing.Point(4, 279);
            this.pBack7.Name = "pBack7";
            this.pBack7.Size = new System.Drawing.Size(444, 40);
            this.pBack7.Visible = false;
            // 
            // lblCreate7
            // 
            this.lblCreate7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate7.Location = new System.Drawing.Point(188, 10);
            this.lblCreate7.Name = "lblCreate7";
            this.lblCreate7.Size = new System.Drawing.Size(138, 20);
            this.lblCreate7.Text = "2011-12-20 19:45";
            // 
            // lblSteet7
            // 
            this.lblSteet7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet7.Location = new System.Drawing.Point(27, 11);
            this.lblSteet7.Name = "lblSteet7";
            this.lblSteet7.Size = new System.Drawing.Size(157, 19);
            this.lblSteet7.Text = "街道地址";
            // 
            // lblId7
            // 
            this.lblId7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId7.Location = new System.Drawing.Point(10, 12);
            this.lblId7.Name = "lblId7";
            this.lblId7.Size = new System.Drawing.Size(39, 30);
            this.lblId7.Text = "7";
            // 
            // pbUpload7
            // 
            this.pbUpload7.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload7.Image")));
            this.pbUpload7.Location = new System.Drawing.Point(384, 3);
            this.pbUpload7.Name = "pbUpload7";
            this.pbUpload7.Size = new System.Drawing.Size(55, 31);
            this.pbUpload7.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn7
            // 
            this.pbIn7.Image = ((System.Drawing.Image)(resources.GetObject("pbIn7.Image")));
            this.pbIn7.Location = new System.Drawing.Point(332, 3);
            this.pbIn7.Name = "pbIn7";
            this.pbIn7.Size = new System.Drawing.Size(52, 31);
            this.pbIn7.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack6
            // 
            this.pBack6.Controls.Add(this.lblCreate6);
            this.pBack6.Controls.Add(this.lblSteet6);
            this.pBack6.Controls.Add(this.lblId6);
            this.pBack6.Controls.Add(this.pbUpload6);
            this.pBack6.Controls.Add(this.pbIn6);
            this.pBack6.Location = new System.Drawing.Point(4, 233);
            this.pBack6.Name = "pBack6";
            this.pBack6.Size = new System.Drawing.Size(444, 40);
            this.pBack6.Visible = false;
            this.pBack6.GotFocus += new System.EventHandler(this.p6_GotFocus);
            // 
            // lblCreate6
            // 
            this.lblCreate6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate6.Location = new System.Drawing.Point(188, 10);
            this.lblCreate6.Name = "lblCreate6";
            this.lblCreate6.Size = new System.Drawing.Size(138, 20);
            this.lblCreate6.Text = "2011-12-20 19:45";
            // 
            // lblSteet6
            // 
            this.lblSteet6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet6.Location = new System.Drawing.Point(27, 11);
            this.lblSteet6.Name = "lblSteet6";
            this.lblSteet6.Size = new System.Drawing.Size(157, 19);
            this.lblSteet6.Text = "街道地址";
            // 
            // lblId6
            // 
            this.lblId6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId6.Location = new System.Drawing.Point(10, 12);
            this.lblId6.Name = "lblId6";
            this.lblId6.Size = new System.Drawing.Size(39, 30);
            this.lblId6.Text = "6";
            // 
            // pbUpload6
            // 
            this.pbUpload6.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload6.Image")));
            this.pbUpload6.Location = new System.Drawing.Point(384, 3);
            this.pbUpload6.Name = "pbUpload6";
            this.pbUpload6.Size = new System.Drawing.Size(55, 31);
            this.pbUpload6.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn6
            // 
            this.pbIn6.Image = ((System.Drawing.Image)(resources.GetObject("pbIn6.Image")));
            this.pbIn6.Location = new System.Drawing.Point(332, 3);
            this.pbIn6.Name = "pbIn6";
            this.pbIn6.Size = new System.Drawing.Size(52, 31);
            this.pbIn6.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack5
            // 
            this.pBack5.Controls.Add(this.lblCreate5);
            this.pBack5.Controls.Add(this.lblSteet5);
            this.pBack5.Controls.Add(this.lblId5);
            this.pBack5.Controls.Add(this.pbUpload5);
            this.pBack5.Controls.Add(this.pbIn5);
            this.pBack5.Location = new System.Drawing.Point(3, 187);
            this.pBack5.Name = "pBack5";
            this.pBack5.Size = new System.Drawing.Size(444, 40);
            this.pBack5.Visible = false;
            // 
            // lblCreate5
            // 
            this.lblCreate5.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate5.Location = new System.Drawing.Point(188, 10);
            this.lblCreate5.Name = "lblCreate5";
            this.lblCreate5.Size = new System.Drawing.Size(138, 20);
            this.lblCreate5.Text = "2011-12-20 19:45";
            // 
            // lblSteet5
            // 
            this.lblSteet5.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet5.Location = new System.Drawing.Point(27, 11);
            this.lblSteet5.Name = "lblSteet5";
            this.lblSteet5.Size = new System.Drawing.Size(157, 19);
            this.lblSteet5.Text = "街道地址";
            // 
            // lblId5
            // 
            this.lblId5.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId5.Location = new System.Drawing.Point(10, 12);
            this.lblId5.Name = "lblId5";
            this.lblId5.Size = new System.Drawing.Size(39, 30);
            this.lblId5.Text = "5";
            // 
            // pbUpload5
            // 
            this.pbUpload5.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload5.Image")));
            this.pbUpload5.Location = new System.Drawing.Point(384, 3);
            this.pbUpload5.Name = "pbUpload5";
            this.pbUpload5.Size = new System.Drawing.Size(55, 31);
            this.pbUpload5.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn5
            // 
            this.pbIn5.Image = ((System.Drawing.Image)(resources.GetObject("pbIn5.Image")));
            this.pbIn5.Location = new System.Drawing.Point(332, 3);
            this.pbIn5.Name = "pbIn5";
            this.pbIn5.Size = new System.Drawing.Size(52, 31);
            this.pbIn5.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack4
            // 
            this.pBack4.Controls.Add(this.lblCreate4);
            this.pBack4.Controls.Add(this.lblSteet4);
            this.pBack4.Controls.Add(this.lblId4);
            this.pBack4.Controls.Add(this.pbUpload4);
            this.pBack4.Controls.Add(this.pbIn4);
            this.pBack4.Location = new System.Drawing.Point(3, 141);
            this.pBack4.Name = "pBack4";
            this.pBack4.Size = new System.Drawing.Size(444, 40);
            this.pBack4.Visible = false;
            // 
            // lblCreate4
            // 
            this.lblCreate4.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate4.Location = new System.Drawing.Point(188, 10);
            this.lblCreate4.Name = "lblCreate4";
            this.lblCreate4.Size = new System.Drawing.Size(138, 20);
            this.lblCreate4.Text = "2011-12-20 19:45";
            // 
            // lblSteet4
            // 
            this.lblSteet4.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet4.Location = new System.Drawing.Point(27, 11);
            this.lblSteet4.Name = "lblSteet4";
            this.lblSteet4.Size = new System.Drawing.Size(157, 19);
            this.lblSteet4.Text = "街道地址";
            // 
            // lblId4
            // 
            this.lblId4.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId4.Location = new System.Drawing.Point(10, 12);
            this.lblId4.Name = "lblId4";
            this.lblId4.Size = new System.Drawing.Size(39, 30);
            this.lblId4.Text = "4";
            // 
            // pbUpload4
            // 
            this.pbUpload4.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload4.Image")));
            this.pbUpload4.Location = new System.Drawing.Point(384, 3);
            this.pbUpload4.Name = "pbUpload4";
            this.pbUpload4.Size = new System.Drawing.Size(55, 31);
            this.pbUpload4.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn4
            // 
            this.pbIn4.Image = ((System.Drawing.Image)(resources.GetObject("pbIn4.Image")));
            this.pbIn4.Location = new System.Drawing.Point(332, 3);
            this.pbIn4.Name = "pbIn4";
            this.pbIn4.Size = new System.Drawing.Size(52, 31);
            this.pbIn4.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack3
            // 
            this.pBack3.Controls.Add(this.lblCreate3);
            this.pBack3.Controls.Add(this.lblSteet3);
            this.pBack3.Controls.Add(this.lblId3);
            this.pBack3.Controls.Add(this.pbUpload3);
            this.pBack3.Controls.Add(this.pbIn3);
            this.pBack3.Location = new System.Drawing.Point(4, 95);
            this.pBack3.Name = "pBack3";
            this.pBack3.Size = new System.Drawing.Size(444, 40);
            this.pBack3.Visible = false;
            // 
            // lblCreate3
            // 
            this.lblCreate3.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate3.Location = new System.Drawing.Point(188, 10);
            this.lblCreate3.Name = "lblCreate3";
            this.lblCreate3.Size = new System.Drawing.Size(138, 20);
            this.lblCreate3.Text = "2011-12-20 19:45";
            // 
            // lblSteet3
            // 
            this.lblSteet3.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet3.Location = new System.Drawing.Point(27, 11);
            this.lblSteet3.Name = "lblSteet3";
            this.lblSteet3.Size = new System.Drawing.Size(157, 19);
            this.lblSteet3.Text = "街道地址";
            // 
            // lblId3
            // 
            this.lblId3.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId3.Location = new System.Drawing.Point(10, 12);
            this.lblId3.Name = "lblId3";
            this.lblId3.Size = new System.Drawing.Size(39, 30);
            this.lblId3.Text = "3";
            // 
            // pbUpload3
            // 
            this.pbUpload3.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload3.Image")));
            this.pbUpload3.Location = new System.Drawing.Point(384, 3);
            this.pbUpload3.Name = "pbUpload3";
            this.pbUpload3.Size = new System.Drawing.Size(55, 31);
            this.pbUpload3.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn3
            // 
            this.pbIn3.Image = ((System.Drawing.Image)(resources.GetObject("pbIn3.Image")));
            this.pbIn3.Location = new System.Drawing.Point(332, 3);
            this.pbIn3.Name = "pbIn3";
            this.pbIn3.Size = new System.Drawing.Size(52, 31);
            this.pbIn3.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack2
            // 
            this.pBack2.Controls.Add(this.lblCreate2);
            this.pBack2.Controls.Add(this.lblSteet2);
            this.pBack2.Controls.Add(this.lblId2);
            this.pBack2.Controls.Add(this.pbUpload2);
            this.pBack2.Controls.Add(this.pbIn2);
            this.pBack2.Location = new System.Drawing.Point(4, 49);
            this.pBack2.Name = "pBack2";
            this.pBack2.Size = new System.Drawing.Size(444, 40);
            this.pBack2.Visible = false;
            // 
            // lblCreate2
            // 
            this.lblCreate2.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate2.Location = new System.Drawing.Point(188, 10);
            this.lblCreate2.Name = "lblCreate2";
            this.lblCreate2.Size = new System.Drawing.Size(138, 20);
            this.lblCreate2.Text = "2011-12-20 19:45";
            // 
            // lblSteet2
            // 
            this.lblSteet2.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet2.Location = new System.Drawing.Point(27, 11);
            this.lblSteet2.Name = "lblSteet2";
            this.lblSteet2.Size = new System.Drawing.Size(157, 19);
            this.lblSteet2.Text = "街道地址";
            // 
            // lblId2
            // 
            this.lblId2.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId2.Location = new System.Drawing.Point(10, 12);
            this.lblId2.Name = "lblId2";
            this.lblId2.Size = new System.Drawing.Size(39, 30);
            this.lblId2.Text = "2";
            // 
            // pbUpload2
            // 
            this.pbUpload2.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload2.Image")));
            this.pbUpload2.Location = new System.Drawing.Point(384, 3);
            this.pbUpload2.Name = "pbUpload2";
            this.pbUpload2.Size = new System.Drawing.Size(55, 31);
            this.pbUpload2.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn2
            // 
            this.pbIn2.Image = ((System.Drawing.Image)(resources.GetObject("pbIn2.Image")));
            this.pbIn2.Location = new System.Drawing.Point(332, 3);
            this.pbIn2.Name = "pbIn2";
            this.pbIn2.Size = new System.Drawing.Size(52, 31);
            this.pbIn2.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBack1
            // 
            this.pBack1.Controls.Add(this.lblCreate1);
            this.pBack1.Controls.Add(this.lblSteet1);
            this.pBack1.Controls.Add(this.lblId1);
            this.pBack1.Controls.Add(this.pbUpload1);
            this.pBack1.Controls.Add(this.pbIn1);
            this.pBack1.Location = new System.Drawing.Point(3, 3);
            this.pBack1.Name = "pBack1";
            this.pBack1.Size = new System.Drawing.Size(444, 40);
            this.pBack1.Visible = false;
            // 
            // lblCreate1
            // 
            this.lblCreate1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblCreate1.Location = new System.Drawing.Point(188, 10);
            this.lblCreate1.Name = "lblCreate1";
            this.lblCreate1.Size = new System.Drawing.Size(138, 20);
            this.lblCreate1.Text = "2011-12-20 19:45";
            // 
            // lblSteet1
            // 
            this.lblSteet1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblSteet1.Location = new System.Drawing.Point(27, 11);
            this.lblSteet1.Name = "lblSteet1";
            this.lblSteet1.Size = new System.Drawing.Size(157, 19);
            this.lblSteet1.Text = "街道地址";
            // 
            // lblId1
            // 
            this.lblId1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.lblId1.Location = new System.Drawing.Point(10, 12);
            this.lblId1.Name = "lblId1";
            this.lblId1.Size = new System.Drawing.Size(39, 30);
            this.lblId1.Text = "1";
            // 
            // pbUpload1
            // 
            this.pbUpload1.Image = ((System.Drawing.Image)(resources.GetObject("pbUpload1.Image")));
            this.pbUpload1.Location = new System.Drawing.Point(384, 3);
            this.pbUpload1.Name = "pbUpload1";
            this.pbUpload1.Size = new System.Drawing.Size(55, 31);
            this.pbUpload1.Click += new System.EventHandler(this.pbUpload_Click);
            // 
            // pbIn1
            // 
            this.pbIn1.Image = ((System.Drawing.Image)(resources.GetObject("pbIn1.Image")));
            this.pbIn1.Location = new System.Drawing.Point(332, 3);
            this.pbIn1.Name = "pbIn1";
            this.pbIn1.Size = new System.Drawing.Size(52, 31);
            this.pbIn1.Click += new System.EventHandler(this.pbIn_Click);
            // 
            // pBUploadAll
            // 
            this.pBUploadAll.Image = ((System.Drawing.Image)(resources.GetObject("pBUploadAll.Image")));
            this.pBUploadAll.Location = new System.Drawing.Point(173, 563);
            this.pBUploadAll.Name = "pBUploadAll";
            this.pBUploadAll.Size = new System.Drawing.Size(133, 42);
            this.pBUploadAll.Click += new System.EventHandler(this.pBUploadAll_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.btnReturn.Location = new System.Drawing.Point(330, 563);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(74, 20);
            this.btnReturn.TabIndex = 28;
            this.btnReturn.Text = "返回";
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold);
            this.btnNew.Location = new System.Drawing.Point(407, 563);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(70, 20);
            this.btnNew.TabIndex = 28;
            this.btnNew.Text = "新信息";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // ucControlManager1
            // 
            this.ucControlManager1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucControlManager1.Location = new System.Drawing.Point(0, 0);
            this.ucControlManager1.Name = "ucControlManager1";
            this.ucControlManager1.Size = new System.Drawing.Size(480, 67);
            this.ucControlManager1.TabIndex = 25;
            // 
            // frmHouseManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(480, 588);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.pBUploadAll);
            this.Controls.Add(this.bgPanel);
            this.Controls.Add(this.ucControlManager1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel7);
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "frmHouseManager";
            this.Text = "frmHouseManager";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.frmHouseManager_Activated);
            this.panel7.ResumeLayout(false);
            this.bgPanel.ResumeLayout(false);
            this.pBack10.ResumeLayout(false);
            this.pBack9.ResumeLayout(false);
            this.pBack8.ResumeLayout(false);
            this.pBack7.ResumeLayout(false);
            this.pBack6.ResumeLayout(false);
            this.pBack5.ResumeLayout(false);
            this.pBack4.ResumeLayout(false);
            this.pBack3.ResumeLayout(false);
            this.pBack2.ResumeLayout(false);
            this.pBack1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MainMenu mainMenu2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox btnReSet;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private PoliceMobile.LIB.ucControlManager ucControlManager1;
        private System.Windows.Forms.Panel bgPanel;
        private System.Windows.Forms.Panel pBack1;
        private System.Windows.Forms.PictureBox pbUpload1;
        private System.Windows.Forms.PictureBox pbIn1;
        private System.Windows.Forms.Label lblCreate1;
        private System.Windows.Forms.Label lblSteet1;
        private System.Windows.Forms.Label lblId1;
        private System.Windows.Forms.Panel pBack9;
        private System.Windows.Forms.Label lblCreate9;
        private System.Windows.Forms.Label lblSteet9;
        private System.Windows.Forms.Label lblId9;
        private System.Windows.Forms.PictureBox pbUpload19;
        private System.Windows.Forms.PictureBox pbIn9;
        private System.Windows.Forms.Panel pBack8;
        private System.Windows.Forms.Label lblCreate8;
        private System.Windows.Forms.Label lblSteet8;
        private System.Windows.Forms.Label lblId8;
        private System.Windows.Forms.PictureBox pbUpload8;
        private System.Windows.Forms.PictureBox pbIn8;
        private System.Windows.Forms.Panel pBack7;
        private System.Windows.Forms.Label lblCreate7;
        private System.Windows.Forms.Label lblSteet7;
        private System.Windows.Forms.Label lblId7;
        private System.Windows.Forms.PictureBox pbUpload7;
        private System.Windows.Forms.PictureBox pbIn7;
        private System.Windows.Forms.Panel pBack6;
        private System.Windows.Forms.Label lblCreate6;
        private System.Windows.Forms.Label lblSteet6;
        private System.Windows.Forms.Label lblId6;
        private System.Windows.Forms.PictureBox pbUpload6;
        private System.Windows.Forms.PictureBox pbIn6;
        private System.Windows.Forms.Panel pBack5;
        private System.Windows.Forms.Label lblCreate5;
        private System.Windows.Forms.Label lblSteet5;
        private System.Windows.Forms.Label lblId5;
        private System.Windows.Forms.PictureBox pbUpload5;
        private System.Windows.Forms.PictureBox pbIn5;
        private System.Windows.Forms.Panel pBack4;
        private System.Windows.Forms.Label lblCreate4;
        private System.Windows.Forms.Label lblSteet4;
        private System.Windows.Forms.Label lblId4;
        private System.Windows.Forms.PictureBox pbUpload4;
        private System.Windows.Forms.PictureBox pbIn4;
        private System.Windows.Forms.Panel pBack3;
        private System.Windows.Forms.Label lblCreate3;
        private System.Windows.Forms.Label lblSteet3;
        private System.Windows.Forms.Label lblId3;
        private System.Windows.Forms.PictureBox pbUpload3;
        private System.Windows.Forms.PictureBox pbIn3;
        private System.Windows.Forms.Panel pBack2;
        private System.Windows.Forms.Label lblCreate2;
        private System.Windows.Forms.Label lblSteet2;
        private System.Windows.Forms.Label lblId2;
        private System.Windows.Forms.PictureBox pbUpload2;
        private System.Windows.Forms.PictureBox pbIn2;
        private System.Windows.Forms.PictureBox pBUploadAll;
        private System.Windows.Forms.Panel pBack10;
        private System.Windows.Forms.Label lblCreate10;
        private System.Windows.Forms.Label lblSteet10;
        private System.Windows.Forms.Label lblId10;
        private System.Windows.Forms.PictureBox pbUpload10;
        private System.Windows.Forms.PictureBox pbIn10;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnNew;


    }
}